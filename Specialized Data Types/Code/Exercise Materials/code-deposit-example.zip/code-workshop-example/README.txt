The following descriptions and metadata indicate the use and purpose of the
information supplied in "data.csv", and "code.txt" accompanying and supporting
the density-dependent habitat selection model for wolves described in the
manuscript REDACTED by REDACTED

GENERAL INFORMATION
-------------------

1. Title of Dataset:

"Code, data, and metadata document for the manuscript: Density-dependence in
wolf resource selection study designs"

2. Author Information: [REDACTED]

3. Date of data collection: 

Field Data: January 1994 - June 2014

Data Geoprocessing and preparing data for models:  June 2014 - May 2017

4. Geographic location of data collection: 

Upper Peninsula, Michigan, USA

5. Information about funding sources that supported the collection of the data:

Michigan Department of Natural Resources


SHARING/ACCESS INFORMATION
-------------------------- 

1. Licenses/restrictions placed on the data: CC0 1.0 Universal,
   http://creativecommons.org/publicdomain/zero/1.0/

2. Links to publications that cite or use the data: [REDACTED]

3. Recommended citation for the data: [REDACTED]


DATA & FILE OVERVIEW
---------------------

1. File List

   A. Filename: data.csv    

      Short description: Geoprocessed data from field locations of wolves (12.35Mb, CSV file)

   B. Filename: code.txt	    

      Short description: statistical code (2.003Kb, Text file)


2. Relationship between files:        


METHODOLOGICAL INFORMATION
--------------------------

1. Description of methods used for collection/generation of data: 

Individuals were located by aerial tracking of VHF radio collars. Packs were
located using visual sightings from aerial tracking and by ground tracking and
following wolf tracks from roads and trails during each winter. 

2. Methods for processing the data:

Delineation of wolf territories was based on 95% kernel density isopleth
analysis when 30 or more locations were available. Otherwise, a combination of
VHF locations and ground tracking locations were used to delineate the
territory. Used (0 vs. 1) column represents an approximate wolf pack location
(randomly sampled within each occupied pack territory for each year of study)  
or random location (randomly sampled from available space primarily outside of
all pack territories for each year of study) Covariate data represent the values
of underlying landscape attributes, generated from Geographic Information
Systems and remotely sensed data sources. These are described in "DATA-SPECIFIC
INFORMATION" and within the manuscript.
 
3. Instrument- or software-specific information needed to interpret the data:

Run code.txt on data.csv in RStudio (R version 3.5.2 (2018-12-20)) after
installing the r-inla library (http://www.r-inla.org/download) as well as listed
dependencies rgraphviz
(https://www.bioconductor.org/packages/release/bioc/html/Rgraphviz.html) and
graph (https://bioconductor.org/packages/3.8/bioc/html/graph.html).


DATA-SPECIFIC INFORMATION FOR: data.csv
-----------------------------------------


COLUMN
DESCRIPTION

Year 
Represents a wolf's biological year, corresponding to the time period during
which new pups are added to the population until the same time the following
year. Used as a random intercept effect within hierarchical generalized linear
mixed model structure.


Pack

Unique wolf pack territory identifier. Wolf packs and territories were
established by information from VHF radio telemetry locations combined with
intensive ground tracking to delineate territory boundaries. Used as a random
intercept effect within hierarchical generalized linear mixed model structure.

Used

This column represents the binary response variable in a hierarchical model for
wolf (Canis lupus) density-dependent habitat selection in the Upper Peninsula of
Michigan, USA, 1995-2013. Each year & wolf pack territory combination received 5
locations sampled within the territory boundary, paired with 25 locations
randomly sampled within unoccupied and available space. The available space for
each pack was constrained to be within 165 km of the geographic center of the
defined wolf territory, based on knowledge about wolf dispersal distances in the
Upper Great Lakes region.   

1 = used wolf location, randomly sampled within each occupied pack territory for
each year of study

0 = random location, randomly sampled from available space outside of each pack
territory for each year of study

X

X-Coordinate in Michigan GeoRef Projected Coordinate System; values are censored
(set to NA) due to sensitive nature of locations of endangered species within
the study area. Coordinate information is not necessary for running the model.


Y

Y-Coordinate in Michigan GeoRef Projected Coordinate System; values are censored
(set to NA) due to sensitive nature of locations of endangered species within
the study area. Coordinate information is not necessary for running the model.

InclProb

Represents an underlying inverse probability of occupancy surface. In other
words, indicating the probability that the random point was sampled from
unoccupied space, given uncertainty in the occupied distribution.


ELEV

Covariate data representing local elevation (m). Underlying values were
extracted to used and random locations using GIS. Detailed description of the
data sources are available in the Supplemental Electronic Material accompanying
the article. 

 
SLOPE

Covariate data representing degree slope. Underlying values were extracted to
used and random locations using GIS. Detailed description of the data sources
are available in the Supplemental Electronic Material accompanying the article.


TRASP

Covariate data representing transformed aspect. Underlying values were extracted
to used and random locations using GIS. Detailed description of the data sources
are available in the Supplemental Electronic Material accompanying the article.


ROUGH

Covariate data representing topographic ruggedness. Underlying values were
extracted to used and random locations using GIS. Detailed description of the
data sources are available in the Supplemental Electronic Material accompanying
the article.


IMPERV

Covariate data representing proportion of impervious developed surface.
Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


HWY

Covariate data representing distance to major road or highway. Underlying values
were extracted to used and random locations using GIS. Detailed description of
the data sources are available in the Supplemental Electronic Material
accompanying the article.


STREAM

Covariate data representing local density of streams (km / km2). Underlying
values were extracted to used and random locations using GIS. Detailed
description of the data sources are available in the Supplemental Electronic
Material accompanying the article.

 
PLAND

Covariate data representing proportion of public and protected land. Underlying
values were extracted to used and random locations using GIS. Detailed
description of the data sources are available in the Supplemental Electronic
Material accompanying the article.


DDWC

Covariate data representing distance to deer wintering complex habitat patches.
Deer wintering complexes represent winter availability of the primary prey
source for wolves due to deep snowpack in this study area during winter.
Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


SNOW

Covariate data representing annual average snow depth (cm) at each 30 m cell,
specific to each each winter. Underlying values were extracted to used and
random locations using GIS. Detailed description of the data sources are
available in the Supplemental Electronic Material accompanying the article.


SNOW_LTA

Covariate data representing long-term average snow depth (cm) at each 30 m cell,
averaged across all study years. Underlying values were extracted to used and
random locations using GIS. Detailed description of the data sources are
available in the Supplemental Electronic Material accompanying the article.


ROAD

Covariate data representing density of minor roads (local roads and trails; km /
km2). Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


EDGE

Covariate data representing density of edge between forested and open land cover
types. Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


AG

Covariate data representing the proportion of agricultural field and pasture.
Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


OPEN

Covariate data representing the proportion of open, non-forested land cover
types. Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


WDENS

Covariate data representing regional wolf density. Wolf density was used to
model habitat functional responses (e.g., density-dependent habitat selection).
A spatial surface was developed and described in the Methods section of the
article, and underlying values were extracted to used and random locations using
GIS. Detailed description of the data sources are available in the Methods
section of the accompanying article.


WATER

Covariate data representing the proportion of open water and wetland cover
types. Underlying values were extracted to used and random locations using GIS.
Detailed description of the data sources are available in the Supplemental
Electronic Material accompanying the article.


PackYear

Combination of 'Pack' and 'Year.' Used in post-hoc analysis.


p_occ

Value representing an estimate of the proportion of the surrounding study area
(<165 km radial buffer) occupied by other wolf territories, specific to the
current pack. This variable is not currently implemented in the model but could
be used as a substitute for time.